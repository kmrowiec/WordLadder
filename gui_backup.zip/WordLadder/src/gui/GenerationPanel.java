package gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

public class GenerationPanel extends JPanel {
	
	public static final String ACTION_GENERATE = "generate_mode_start";

	JTextField wordField = new JTextField(10);
	JSpinner stepsField = new JSpinner(new SpinnerNumberModel());
	JButton startButton = new JButton("Generate Ladder");
	
	JPanel textFields = new JPanel(new GridLayout(2, 2));
	
	public GenerationPanel(ActionListener buttonListener){
		super();
		this.setLayout(new BorderLayout());
		
		textFields.add(new JLabel("Start word: "));
		textFields.add(wordField);
		textFields.add(new JLabel("Number of steps: "));
		textFields.add(stepsField);
		
		startButton.setActionCommand(ACTION_GENERATE);
		startButton.addActionListener(buttonListener);
		
		SpinnerNumberModel spinnerModel = (SpinnerNumberModel) stepsField.getModel();
		spinnerModel.setMinimum(1);
		spinnerModel.setMaximum(50);
		spinnerModel.setValue(1);
		
		this.add(textFields, BorderLayout.WEST);
		this.add(startButton, BorderLayout.EAST);
	}
	
	public String getWord(){
		return wordField.getText();
	}
	
	public int getSteps(){
		return Integer.parseInt(stepsField.getValue().toString());
	}
}
