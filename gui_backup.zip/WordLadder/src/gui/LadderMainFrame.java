/**
 * 
 */
package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import main.WordLadder;

/**
 * @author kamil
 *
 */
public class LadderMainFrame extends JFrame implements ActionListener{

	JTabbedPane tabs = new JTabbedPane();
	GenerationPanel generationPanel = new GenerationPanel(this);
	DiscoveryPanel discoveryPanel = new DiscoveryPanel(this);
	LoadDictPanel loadDictPanel = new LoadDictPanel(this);
	
	WordLadder wordLadder = new WordLadder();
	
	JTextArea outputText = new JTextArea("Hello");
	JScrollPane outputScroll = new JScrollPane(outputText);
	
	public LadderMainFrame(){
		//this.setSize(300, 400);
		this.setTitle("WordLadder");
		this.setLayout(new BorderLayout());
		
		
		tabs.addTab("Generation Mode", null, generationPanel);
		tabs.addTab("Discovery Mode", null, discoveryPanel);
		
		outputText.setRows(20);
		
		this.add(tabs, BorderLayout.NORTH);
		this.add(outputScroll, BorderLayout.CENTER);
		this.add(loadDictPanel, BorderLayout.SOUTH);
		
		this.pack();
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String command = arg0.getActionCommand();
		
		if(command.equals(LoadDictPanel.ACTION_LOAD)){
			loadDictFile();
		}else if(command.equals(GenerationPanel.ACTION_GENERATE)){
			generate();
		}else if(command.equals(DiscoveryPanel.ACTION_DISCOVERY)){
			discovery();
		}
		
	}
	
	public void loadDictFile(){
		JFileChooser chooser = new JFileChooser(".");
		chooser.setMultiSelectionEnabled(false);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.showOpenDialog(this);
		wordLadder.loadGraph(chooser.getSelectedFile());
		loadDictPanel.setLabelText("Dictionary: " + chooser.getSelectedFile().getName());
	}
	
	public void generate(){
		try{

		outputText.append("\n--------------------------------------------------------------------------------");
		outputText.append("\nGenerating word ladder for: \"" + generationPanel.getWord()+
				"\", consisting of " + generationPanel.getSteps() + " steps.");
		outputText.append("\n" + wordLadder.getLadder(generationPanel.getWord(), generationPanel.getSteps()));
		}catch(Exception ex){
			
		}
	}
	
	public void discovery(){
		try{
		outputText.append("\n--------------------------------------------------------------------------------");
		outputText.append("\nGenerating word ladder from: \"" + discoveryPanel.getStartWord()+
				"\" to " + discoveryPanel.getEndWord());
		outputText.append("\n" + wordLadder.getLadder(discoveryPanel.getStartWord(), discoveryPanel.getEndWord()));
		}catch(Exception ex){
			
		}
		}
}
