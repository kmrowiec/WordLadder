/**
 * 
 */
package gui;

/**
 * @author kamil
 *
 */
public class RunWordLadder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LadderMainFrame frame = new LadderMainFrame();
	}

}
