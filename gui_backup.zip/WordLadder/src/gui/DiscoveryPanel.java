package gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DiscoveryPanel extends JPanel {

	public static final String ACTION_DISCOVERY = "discovery";
	
	JTextField startField = new JTextField(10);
	JTextField endField = new JTextField(10);
	
	JPanel textFields = new JPanel(new GridLayout(2, 2));
	JButton startButton = new JButton("Generate Ladder");
	
	public DiscoveryPanel(ActionListener buttonListener){
		super();
		
		textFields.add(new JLabel("Start word: "));
		textFields.add(startField);
		textFields.add(new JLabel("End word: "));
		textFields.add(endField);
		
		startButton.addActionListener(buttonListener);
		startButton.setActionCommand(ACTION_DISCOVERY);
		
		this.add(textFields, BorderLayout.WEST);
		this.add(startButton, BorderLayout.EAST);
		
	}
	
	public String getStartWord(){
		return startField.getText();
	}
	
	public String getEndWord(){
		return endField.getText();
	}
}
