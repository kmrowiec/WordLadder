/**
 * 
 */
package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * @author kamil
 *
 */
public class LoadDictPanel extends JPanel {
	
	public static final String ACTION_LOAD = "load_dict";
	

	JTextField filePath = new JTextField("Load dictionary file.");
	JButton loadButton = new JButton("LOAD");
	
	public LoadDictPanel(ActionListener buttonListener){
		super();
		this.setLayout(new BorderLayout());
		loadButton.setActionCommand(ACTION_LOAD);
		loadButton.addActionListener(buttonListener);
		this.add(filePath, BorderLayout.CENTER);
		this.add(loadButton, BorderLayout.EAST);
		
	}
	
	public void setLabelText(String s){
		filePath.setText(s);
	}
}
